package com.sofudev.sipphcheck.model

class MyColor(
    val r : Int,
    val g : Int,
    val b : Int
)